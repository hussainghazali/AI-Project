import pandas as pd
import numpy as np
import matplotlib.pylab as plt
from collections import Counter
import matplotlib as mpl
from sklearn import preprocessing
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.cluster import KMeans

df = pd.read_json('train.json')
df.head()

features_all_list = []

for i in df.ingredients:
    features_all_list += i

features = list( set(features_all_list) )

len(features)

onehot_ingredients = np.zeros((df.shape[0], len(features)))

feature_lookup = sorted(features)

for index, row in df.iterrows():
    for ingredient in row['ingredients']:
        onehot_ingredients[index, feature_lookup.index(ingredient)] = 1

y = df.cuisine.values.reshape(-1,1)

df_features = pd.DataFrame(onehot_ingredients)

d = {}

for i in range(len(features)):
    d[df_features.columns[i]] = features[i]

df_features = df_features.rename(columns=d)
df_features.shape

from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(df_features, y, test_size=0.2, shuffle=True, random_state=42)

from sklearn.tree import DecisionTreeClassifier

clf = DecisionTreeClassifier(max_features=5000)

clf.fit(X_train, y_train)

y_pred = clf.predict(X_test)

a = accuracy_score(y_test, y_pred)
print("Accuracy Score in % : ")
print(a * 100)

clf = RandomForestClassifier()

clf.fit(X_train, y_train.ravel())

y_pred = clf.predict(X_test)

a = accuracy_score(y_test, y_pred)
print("Accuracy Score in % : ")
print(a * 100)

clf = RandomForestClassifier(max_depth=200, n_estimators=250, max_features='sqrt', min_samples_split=7)

clf = LogisticRegression(random_state=0, solver='lbfgs',multi_class='multinomial').fit(X_train, y_train.ravel())

y_pred = clf.predict(X_test)

a = accuracy_score(y_test, y_pred)
print("Accuracy Score in % : ")
print(a * 100)

data_agg = df.groupby('cuisine').apply(lambda x: x.sum())
data_agg = data_agg.drop(columns=['cuisine','id'])
data_agg = data_agg.reset_index()

features_all_list = []

for i in df.ingredients:
    features_all_list += i
    
features = list(set(features_all_list))
len(features)

onehot_ingredients = np.zeros((data_agg.shape[0], len(features)))
feature_lookup = sorted(features)

numOfClusters = 5

kmeans = KMeans(init='k-means++', n_clusters=numOfClusters, n_init=10)

kmeans.fit(reduced_data)

kmeans_pred = kmeans.predict(reduced_data)

x = reduced_data[:, 0]
y = reduced_data[:, 1]

plt.rcParams.update({'font.size':15
                    })

fig, ax = plt.subplots(figsize=(10,10))

ax.scatter(x, y, s=5000, c=kmeans_pred, cmap='Set3')

for i, txt in enumerate(data_agg.cuisine):
    ax.annotate(txt, (x[i], y[i]))
    
    